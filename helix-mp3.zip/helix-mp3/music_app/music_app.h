#ifndef MUSIC_APP_H_
#define MUSIC_APP_H_


void prvMusicappTask(void * pvParameters);  //任务函数


#endif /* MUSIC_APP_H_ */
