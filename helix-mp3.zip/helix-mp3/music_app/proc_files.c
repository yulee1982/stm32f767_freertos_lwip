#include "proc_files.h"
#include "ff.h"
#include <stddef.h>
#include <string.h>
#include "tm_stm32f7_fatfs.h"

char FileList[MAX_FILE_NUMBER_PER_DIR][13];
char FolderList[MAX_DIR_NUMBER][13];

const char* MUSIC_EXTNAME_FILTER[] = {"MP3","WAV","FLA",""};

uint8_t CheckExtName(const char* path,const char** extname)
{
	uint8_t i = 0;
	char* ch = strrchr(path,'.');
	
	if(ch == NULL)
		return 0;
	
	if(*extname[0] == '\0')
		return 1;//δָ����չ�� ��������
	
	while(*extname[i] != '\0')
	{
		if(!strncasecmp(ch+1,extname[i],strlen(extname[i])))
			return 1;
		i ++;
	}
	
	return 0;
}

uint16_t ReadRootDir(void)
{
	uint16_t cnt = 1;
	DIR dir;
	FILINFO fileinfo;
	FRESULT res = FR_OK;
	
	strcpy(FolderList[0],"1:");//第一个目录是根目录
	res = f_opendir(&dir,FolderList[0]);//打开根目录

	while(1)
	{
		res = f_readdir(&dir,&fileinfo);
#if FF_USE_LFN
		if(/*(fileinfo.altname[0] == '\0') || */(fileinfo.fname[0] == '\0') || (res != FR_OK))
			break;

		if(((fileinfo.fattrib & AM_DIR) == 0)||((fileinfo.fattrib & AM_SYS) != 0)||((fileinfo.fattrib & AM_HID) != 0))
			continue;
		
		strcpy(FolderList[cnt],fileinfo.fname);
#else
		if(fileinfo.fname[0] == '\0' || res != FR_OK)
			break;

		if((fileinfo.fattrib & AM_DIR) == 0)
			continue;
		
		strcpy(FolderList[cnt],fileinfo.fname);
#endif
		cnt ++;
		if (cnt >= MAX_DIR_NUMBER)
			break;
	}
	
	f_closedir(&dir);
	
	return cnt;
}

uint16_t ReadFileList(char* dir_str)
{
	uint16_t cnt = 0;
	DIR dir;
	FILINFO fileinfo;
	FRESULT res;
	char root_folderdir[13] = {"1:"};
	char tmp_FolderDir[32];
    char * dir_source;
	char * dir_dest; // = root_folderdir;
    unsigned char ctr = 0;
    int result;

    dir_source = dir_str;
    dir_dest = &tmp_FolderDir[0];
    for(;;)
    {
      if((*dir_dest++ = *dir_source++))
        ctr++;
      else
        break;
    }
    result = strncmp((const char*)root_folderdir, (const char *)&tmp_FolderDir, ctr); //判断是否相等
    if(result == 0) //相等
    {
    	dir_dest = dir_str;
    }else{
    	tmp_FolderDir[0] = '1';
    	tmp_FolderDir[1] = ':';
    	//tmp_FolderDir[2] = '/';
    	dir_dest = &tmp_FolderDir[2];
    	dir_source = dir_str;
        for(;;)
        {
          if((*dir_dest++ = *dir_source++))
            ctr++;
          else
            break;
        }
        dir_dest = &tmp_FolderDir[0];
    }
	
    res = f_opendir(&dir,dir_dest); //res = f_opendir(&dir,dir_str);
    if(res != FR_OK)
    {
    	f_closedir(&dir);
    	return cnt;
    }
	while(1)
	{
		res = f_readdir(&dir,&fileinfo);
#if FF_USE_LFN
		if(/*(fileinfo.altname[0] == '\0') || */(fileinfo.fname[0] == '\0') || (res != FR_OK))
			break;

		if(fileinfo.fattrib & AM_DIR)
			continue;

		if(!CheckExtName(fileinfo.fname,MUSIC_EXTNAME_FILTER))
			continue;
		
		strcpy(FileList[cnt],fileinfo.fname);
#else
		if(fileinfo.fname[0] == '\0' || res != FR_OK)
			break;
		
		if(fileinfo.fattrib & AM_DIR)
			continue;
		
		if(!CheckExtName(fileinfo.fname,MUSIC_EXTNAME_FILTER))
			continue;
		
		strcpy(FileList[cnt],fileinfo.fname);
#endif
		cnt ++;
		if (cnt >= MAX_FILE_NUMBER_PER_DIR)
			break;
	}
	
	f_closedir(&dir);
	
	return cnt;
}

