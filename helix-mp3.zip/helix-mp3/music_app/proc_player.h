#ifndef __PROC_PLAYER_H__
#define __PROC_PLAYER_H__

//#include "common.h"
#include "audio_common.h"

extern uint8_t Volume,PlayMode;

AudioPlayRes MP3_Player(void);

#endif
