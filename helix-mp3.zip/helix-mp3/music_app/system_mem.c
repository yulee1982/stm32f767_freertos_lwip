#include "system_mem.h"

//uint32_t I2Sbuf1[FLAC_OUTPUT_BUFFER_SIZE];
//uint32_t I2Sbuf2[FLAC_OUTPUT_BUFFER_SIZE];

//uint32_t DecodeBuf[FLAC_OUTPUT_BUFFER_SIZE*2];

uint8_t FileBuf[READ_BUFFER_SIZE];
uint16_t decBuffer[DECODED_AUDIO_FRAME_SIZE];	//Buffer used for decoding audio data
uint16_t dmaBuffer[DMA_BUFFER_SIZE];			//Buffer for copying audio data and playing music via I2S

FIL AudioFile;

volatile enum DMABufferStateTypeDef DMABufferState;

#if 0
/* Variable used to control file reading */

int nRead, bytes_left;
int err;
int outOfData;  /* There is no data in the file read buffer*/
int eofReached; /* end of file*/
int nFrames;
//static uint32_t  bytes_leftBeforeDecoding;

/*
 Variable used to control the filling of the audio decoding buffer,
 indicating when the decoding function has completed decoding
 and the amount of data in the file buffer that has not yet been read
 */
uint32_t  offset;

unsigned char *read_ptr;
//static uint32_t bytes_to_read;	// Read data to fill the input buffer
/* Variable used to control file reading */


/* Buffer for file reading, audio decoding and audio playback */
unsigned char inBuffer[READ_BUFFER_SIZE];		//Buffer used for reading files
uint16_t decBuffer[DECODED_AUDIO_FRAME_SIZE];	//Buffer used for decoding audio data
uint16_t dmaBuffer[DMA_BUFFER_SIZE];			//Buffer for copying audio data and playing music via I2S
/* Buffer for file reading, audio decoding and audio playback */


/* Playback control variable */
volatile enum DMABufferStateTypeDef DMABufferState;	//Auxiliary variable for controlling DMA buffer status
volatile enum PlayerStateTypeDef PlayerState;
/* Playback control variable */

#endif





