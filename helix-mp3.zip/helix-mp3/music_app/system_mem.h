#ifndef __SYSTEM_MEM_H__
#define __SYSTEM_MEM_H__

#include "ff.h"


#include "mp3dec.h"
#define READBUF_SIZE_4_MP3				2048 /*ok*/	//3072 /*ok*/	//4096 /*ok*/
#define DECODED_AUDIO_FRAME_SIZE_MP3	MAX_NCHAN * MAX_NGRAN * MAX_NSAMP	//2304 = 2 * 2 * 576
#define DMA_BUFFER_SIZE_MP3				2*DECODED_AUDIO_FRAME_SIZE_MP3		//4608


#define READ_BUFFER_SIZE  2048 //4096
#define DECODED_AUDIO_FRAME_SIZE   DECODED_AUDIO_FRAME_SIZE_MP3
#define DMA_BUFFER_SIZE   DMA_BUFFER_SIZE_MP3


#define WAV_OUTPUT_BUFFER_SIZE   READBUF_SIZE_4_MP3            //2048
#define MP3_OUTPUT_BUFFER_SIZE   DECODED_AUDIO_FRAME_SIZE_MP3  //2304
#define FLAC_OUTPUT_BUFFER_SIZE  DMA_BUFFER_SIZE_MP3           //4608


//extern uint32_t I2Sbuf1[];
//extern uint32_t I2Sbuf2[];

//extern uint32_t DecodeBuf[];
extern uint8_t FileBuf[READ_BUFFER_SIZE];
extern uint16_t decBuffer[DECODED_AUDIO_FRAME_SIZE];
extern uint16_t dmaBuffer[DMA_BUFFER_SIZE];

extern FIL AudioFile;
extern uint8_t DataRequestFlag;

enum DMABufferStateTypeDef
{
  DMABuffer_Full,
  DMABuffer_1stHalf_empty,
  DMABuffer_2ndHalf_empty,
  DMABuffer_Empty						//aka DMABuffer_1stHalf_empty | DMABuffer_2ndHalf_empty
};

extern volatile enum DMABufferStateTypeDef DMABufferState;

#if 0

enum PlayerStateTypeDef{
	Player_stopped,
	Player_playing,
	Player_paused,
	Player_error
};


extern volatile enum PlayerStateTypeDef PlayerState;
int FillReadBuffer(unsigned char *readBuf, unsigned char *readPtr, int bufSize, int bytesLeft, FILE *infile);
#endif
#endif
