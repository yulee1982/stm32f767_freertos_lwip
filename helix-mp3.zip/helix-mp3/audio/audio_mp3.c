#include "audio_common.h"
#include "mp3dec.h"
#include "audio_mp3.h"
#include "pcm5102.h"
#include "string.h"
#include "system_mem.h"
#include "ff.h"
#include "tm_stm32f7_fatfs.h"

uint8_t* MP3_INPUT_BUFFER;


static AudioPlayRes Mp3ReadId3V1Tag(FIL* file, MP3_Info *pctrl,unsigned char option)
{
  //ID3V1_Tag *id3v1tag;
  uint8_t id3hd[10];
  uint32_t br;
	
  f_lseek(file,f_size(file)-128);//Offset to 128 bytes before the end of the file
  //f_read(file, MP3_INPUT_BUFFER,128-(4+30+1), (UINT*)&br);//Read the file ignoring the year, notes and genre
  f_read(file, id3hd, 10, (UINT*)&br);//only read 10 byte

  //id3v1tag = (ID3V1_Tag*)MP3_INPUT_BUFFER;
	
  //if(strncmp("TAG",(char*)id3v1tag->id,3)==0)//是MP3 ID3V1 TAG
  if((id3hd[0] == 'T') &&(id3hd[1] == 'A') &&(id3hd[2] == 'G'))
    return AudioPlay_OK;
  else
    return AudioPlay_MP3_NoID3v1Tag;
}

static AudioPlayRes Mp3ReadId3V2Tag(FIL* file, MP3_Info *pMP3info)
{
  ID3V2_TagHead *taghead;
  uint8_t id3hd[sizeof(ID3V2_TagHead)];
  uint32_t br;
  uint32_t id3v2size;//Frame size
  FRESULT ret;
	
	ret = f_lseek(file,0);//Move to the beginning of the file
	if(ret != FR_OK)
		return AudioPlay_ReadFileError;
	
	ret = f_read(file, id3hd, sizeof(ID3V2_TagHead), (UINT*)&br);//Read ID3V2 tag header
	if((ret != FR_OK)/* || (br != sizeof(ID3V2_TagHead))*/)
		return AudioPlay_ReadFileError;

	taghead = (ID3V2_TagHead*)id3hd;
	//if((id3hd[0] == 'I') &&(id3hd[1] == 'D') &&(id3hd[2] == '3'))
	if(strncmp("ID3",(char*)taghead->id,3) == 0)//The first three characters are 'ID3'
	{
		//id3v2size = ((id3hd[6] & 0x7f) << 21) | ((id3hd[7] & 0x7f) << 14) | ((id3hd[8] & 0x7f) << 7) | (id3hd[9] & 0x7f);
		id3v2size=((uint32_t)taghead->size[0]<<21)|((uint32_t)taghead->size[1]<<14)|((uint16_t)taghead->size[2]<<7)|taghead->size[3];//得到tag大小 4个字节是大端模式 只取低7位
		
		pMP3info->DataStartOffset = id3v2size;//Get the offset where the mp3 data starts
	}
	else
	{
		pMP3info->DataStartOffset = 0;//不存在ID3,mp3数据是从0开始
		return AudioPlay_MP3_NoID3v2Tag;
	}
	
	return AudioPlay_OK;
}

//Get basic MP3 information
//Return value: 0, success; Others, failure
static AudioPlayRes mp3_getinfo(FIL* fmp3,MP3_Info* pMP3info)
{
  MP3FrameInfo frame_info;
  HMP3Decoder decoder;
  MP3_FrameXing* fxing;
  MP3_FrameVBRI* fvbri;
  AudioPlayRes res = AudioPlay_OK;
	
  unsigned char mp3_id3_present = 0; //Is there an ID3V2 ?
  int offset = 0;//Frame synchronisation data offset relative to the array head
  unsigned int br;
  short samples_per_frame;//Number of samples per frame
  unsigned int p;//Pointer used to identify VBR data blocks
  unsigned int filesize;//File size
  unsigned int totframes;//Total frames

  filesize = f_size(fmp3);//Get the MP3 file size

  if(!Mp3ReadId3V2Tag(fmp3, pMP3info))//Decode ID3V2 data
  {
    mp3_id3_present = 1;//There have ID3V2
    filesize -= pMP3info->DataStartOffset;//If have ID3V2, subtract its size
  }

  if(!Mp3ReadId3V1Tag(fmp3,pMP3info,!mp3_id3_present))//Decode ID3V1 data, does not allow overwriting ID3V2
  {
    filesize -= 128;//If have ID3V1, subtract its size
  }

  pMP3info->DataSize = filesize;

  f_lseek(fmp3, pMP3info->DataStartOffset);//Offset to the start of the data

  f_read(fmp3, MP3_INPUT_BUFFER, 4096, (UINT*)&br);//Read the full buffer
	
  decoder = MP3InitDecoder();//MP3 decoding requests memory
  offset = MP3FindSyncWord(MP3_INPUT_BUFFER, br);//Search for frame synchronization information
  //Frame synchronization information found and the next frame information is obtained normally
  if((offset >= 0) && (MP3GetNextFrameInfo(decoder, &frame_info, &MP3_INPUT_BUFFER[offset]) == 0))
  {
    p = offset + 4 + 32;//Skip the frame header (4 bytes) and channel information (32 bytes) to offset to the data area
    fvbri = (MP3_FrameVBRI*)(MP3_INPUT_BUFFER + p);//The VBR file header is located in the data area of the first valid frame
		
    if(!strncmp("VBRI", (char*)fvbri->id, 4))//VBRI frame exists
    {
      if(frame_info.version == MPEG1)
        samples_per_frame = 1152;//MPEG1,layer3 : The number of samples per frame is 1152
      else
        samples_per_frame = 576;//MPEG2/MPEG2.5,layer3 : The number of samples per frame is 576
			
      totframes = BigEndianTab2LittleEndianInt(fvbri->frames);//得到总帧数
      pMP3info->TotalSec = totframes * samples_per_frame / frame_info.samprate;//得到文件总长度 总帧数乘以每帧的采样数除以采样率
    }
    else//Not a VBRI frame, try if it is a Xing frame or an Info frame
    {
      if(frame_info.version == MPEG1)//MPEG1
      {
        p = (frame_info.nChans==2) ? 32:17;//Determine the offset for the number of channels
        samples_per_frame = 1152;//MPEG1,layer3 : The number of samples per frame is 1152
      }else{
        p = (frame_info.nChans==2) ? 17:9;
        samples_per_frame = 576;//MPEG2/MPEG2.5,layer3 : The number of samples per frame is 576
      }
			
      p += (offset+4);
      fxing = (MP3_FrameXing*)(MP3_INPUT_BUFFER + p);
			
      if(!strncmp("Xing",(char*)fxing->id,4) || !strncmp("Info",(char*)fxing->id,4))// is Xing frame or Info frame
      {
        if(fxing->flags[3] & 0x01)//Total frame number field (存在总帧数字段)
		{
		  totframes = BigEndianTab2LittleEndianInt(fxing->frames);//Total frame number
		  pMP3info->TotalSec = totframes * samples_per_frame / frame_info.samprate;//得到文件总长度 总帧数乘以每帧的采样数除以采样率
		}else{
		  pMP3info->TotalSec = filesize/(frame_info.bitrate/8);//Calculate using file size
		}
      }
      else//CBR format
      {
        pMP3info->TotalSec = filesize/(frame_info.bitrate/8); //Calculate using file size
      }
    }
		
    pMP3info->Bitrate = frame_info.bitrate;//Bitrate of the current frame
    pMP3info->Samplerate = frame_info.samprate;//Sampling rate of the current frame
    pMP3info->Channels = frame_info.nChans;//Number of channels in the current frame
		
    if(frame_info.nChans==2)
      pMP3info->SampleSize = frame_info.outputSamps; //Output PCM data size
    else
      pMP3info->SampleSize = frame_info.outputSamps*2;//对于单声道MP3,直接*2,补齐为双声道输出
  }
  else
  {
    res = AudioPlay_UnsupportedFormat;
  }
	
  MP3FreeDecoder(decoder);//Free memory

  return res;
}

static int FillReadBuffer(unsigned char *readBuf, unsigned char *readPtr, int bufSize, int bytesLeft, FILE *infile)
{
  UINT nRead;
  uint32_t bytes_to_read = bufSize - bytesLeft;

  memcpy(readBuf, readPtr, bytesLeft);
  f_read(infile, readBuf + bytesLeft, bytes_to_read, &nRead);

  if(nRead < bytes_to_read)
    memset(readBuf + bytesLeft + nRead, NULL, bytes_to_read - nRead);

  return (uint32_t) nRead;	//return (uint32_t) bytesLeft + (uint32_t) nRead;
}

AudioPlayRes MP3_Play(char* path)
{
  AudioPlayRes res = AudioPlay_OK;
  HMP3Decoder mp3decoder = NULL;
  MP3FrameInfo mp3frameinfo;
  uint8_t* readptr;//MP3 decode read pointer
  uint16_t* pOutputBuffer;//Pointer to the output buffer
  int32_t offset,bytesleft;//The valid data remaining in the buffer
  uint32_t br;
  int err;
  MP3_Info __MP3Info;
  MP3_Info* MP3Info;

  MP3_INPUT_BUFFER = FileBuf;
  MP3Info = &__MP3Info;
	
  memset(MP3Info,0,sizeof(MP3_Info));
  memset(&fs_file,0,sizeof(FIL));

  /*
  res = f_open(&fs_file, "1:music/test.txt", FA_OPEN_EXISTING | FA_READ);
  if(res == 0)
  {
    res = f_read(&fs_file, fs_readbuffer, sizeof(fs_readbuffer), &fs_fnum);
  }
  f_close(&fs_file);

  res = f_open(&fs_file, "1:1.txt", FA_OPEN_EXISTING | FA_READ);
  if(res == 0)
  {
    res = f_read(&fs_file, fs_readbuffer, sizeof(fs_readbuffer), &fs_fnum);
  }
  f_close(&fs_file);
  */

  res = f_open(&fs_file, path, FA_READ); //f_open(MP3_File,path,FA_READ);
  if(res)
  {
    res =  AudioPlay_OpenFileError;
  }
  else
  {
    res = mp3_getinfo(&fs_file, MP3Info); //Get file information
		
    if(!res)
    {
      AudioPlayInfo.FileType = AudioFileType_MP3;
      AudioPlayInfo.Channels = MP3Info->Channels;
			
      AudioPlayInfo.TotalSec = MP3Info->TotalSec;
      AudioPlayInfo.Samplerate = MP3Info->Samplerate;
      AudioPlayInfo.Bitrate = MP3Info->Bitrate/1000;
      AudioPlayInfo.BufferSize = MP3Info->SampleSize*2;
      //AudioPlayInfo.Flags |= AUDIO_FLAG_INFO_READY;
			
      if(AudioPlay_I2SConfig(16,MP3Info->Samplerate,MP3Info->SampleSize))
      {
        res = AudioPlay_UnsupportedParameter;
      }
    }
  }
	
  if(res == AudioPlay_OK)
  {
    mp3decoder = MP3InitDecoder();//MP3 Decoder initialization
		
    f_lseek(&fs_file, MP3Info->DataStartOffset);//Offset to the start of the data

    //-----------------------------------------------------
    bytesleft = 0;
    readptr = MP3_INPUT_BUFFER;//MP3 read pointer points to the start address of the buffer
    pOutputBuffer = decBuffer;
    DMABufferState = DMABuffer_Empty;

    while(res == AudioPlay_OK)
    {
      if(bytesleft < (2 * MAINBUF_SIZE))
      {
        //br = FillReadBuffer(MP3_INPUT_BUFFER, readptr, READ_BUFFER_SIZE, bytesleft, &fs_file);
        //bytesleft += br;
        //readptr = MP3_INPUT_BUFFER;
        //if(br == 0){
        //  eofReached= 1;
        //}

       // if(bytesleft != 0)
		  memmove(MP3_INPUT_BUFFER, readptr, bytesleft);//Move the remaining part of the input array to the front

		if(f_read(&fs_file, (MP3_INPUT_BUFFER + bytesleft), (MP3_INPUT_BUFFER_SIZE-bytesleft), (UINT*)&br))//Supplement the remaining data
		{
          res = AudioPlay_ReadFileError;
		}

		if(br < (MP3_INPUT_BUFFER_SIZE-bytesleft))//If the read data does not fill the input data buffer
		{
          memset((MP3_INPUT_BUFFER + bytesleft + br), 0, (MP3_INPUT_BUFFER_SIZE - bytesleft - br));//补0
		}

		bytesleft = MP3_INPUT_BUFFER_SIZE;//Reset read pointer and remaining bytes
		readptr = MP3_INPUT_BUFFER;
      }

      offset = MP3FindSyncWord(readptr, bytesleft);//Start searching for the synchronization character at the readptr position
      if(offset < 0)//No synchronous character found, exit loop at the end of playback
      {
        res = AudioPlay_PlayEnd;
        break;
      }
      readptr += offset;    //MP3 read pointer offset to the sync character
      bytesleft -= offset;  //The number of valid data in the buffer
      MP3Info->CurrentSec = MP3Info->TotalSec * (fs_file.fptr - MP3Info->DataStartOffset) / MP3Info->DataSize;//Calculate playback time
      AudioPlayInfo.CurrentSec = MP3Info->CurrentSec;

      err = MP3Decode(mp3decoder, &readptr, (int*)&bytesleft, (short*)pOutputBuffer, 0);
 	  switch(err)
	  {
	    case ERR_MP3_NONE:
		  MP3GetLastFrameInfo(mp3decoder, &mp3frameinfo); //Currently decoding MP3 frame information
		  if(MP3Info->Bitrate != mp3frameinfo.bitrate)//Update Bitrate
		  {
            MP3Info->Bitrate = mp3frameinfo.bitrate;
            AudioPlayInfo.Bitrate = mp3frameinfo.bitrate;//Update bit rate
		  }

		  if(mp3frameinfo.nChans == 1) //Mono
		    MonoChannelFill(pOutputBuffer,mp3frameinfo.outputSamps);//Fill the data into stereo

	      if(AudioPlay_I2SConfig(16, MP3Info->Samplerate, MP3Info->SampleSize))
	      {
	        res = AudioPlay_UnsupportedParameter;
	      }

		  //playIfReady(&dmaBuffer, DMA_BUFFER_SIZE_MP3, (uint32_t) mp3FrameInfo.samprate);
	      Play_Start();
		  if(res == AudioPlay_OK)
            wait4_I2S_DMA_SyncSignal();  //The buffer is full, waiting for synchronization with the buffer interval
		  fill_DMAbuffer(dmaBuffer, pOutputBuffer, DMA_BUFFER_SIZE_MP3);
		  break;

	    case ERR_MP3_MAINDATA_UNDERFLOW:
		  // do nothing - next call to decode will provide more mainData
		  break;

	    case ERR_MP3_FREE_BITRATE_SYNC:
		  break;

	    case ERR_MP3_INDATA_UNDERFLOW:
		  printf("Mp3Dec: Decoding error ERR_MP3_INDATA_UNDERFLOW\r\n");
		  //outOfData = TRUE;
		  break;

	    default:
		  printf("Mp3Dec: Decoding error %d\r\n", err);
		  //outOfData = TRUE;
		  break;
	  }
    }
    //-----------------------------------------------------


    if(f_read(&fs_file, MP3_INPUT_BUFFER, 4096, (UINT*)&br))//填充满缓冲区
    {
      res = AudioPlay_ReadFileError;
    }
		
    bytesleft = br;//The data read is all valid data
    readptr = MP3_INPUT_BUFFER;//MP3 read pointer points to the start address of the buffer
		
    Play_Start();

    while(res == AudioPlay_OK)//没有出现数据异常(即可否找到帧同步字符)
    {
      offset = MP3FindSyncWord(readptr, bytesleft);//在readptr位置,开始查找同步字符
      if(offset < 0)//没有找到同步字符 播放结束也依赖此处跳出循环
      {
        res = AudioPlay_PlayEnd;
        break;
      }
      else//找到同步字符了
      {
        readptr += offset;    //MP3读指针偏移到同步字符处
        bytesleft -= offset;  //buffer里面的有效数据个数 帧同步之前的数据视为无效数据减去

        MP3Info->CurrentSec = MP3Info->TotalSec * (fs_file.fptr - MP3Info->DataStartOffset) / MP3Info->DataSize;//计算播放时间
				
        AudioPlayInfo.CurrentSec = MP3Info->CurrentSec;
				
        /* User code area */
        res = MusicPlayingProcess();
        if(res)
          break;
        /* User code area */
								
        AudioPlay_PendSem();
        pOutputBuffer = dmaBuffer;//AudioPlay_GetNextBuff();//并获得当前空闲缓冲区的地址
				
        if(MP3Decode(mp3decoder, &readptr, (int*)&bytesleft, (short*)pOutputBuffer, 0))//解码一帧MP3数据 直接解码到I2S的缓冲区里 节约内存
        {
          res = AudioPlay_DamagedFile;//如果解码错误 跳出帧解码循环
        }
				
        MP3GetLastFrameInfo(mp3decoder,&mp3frameinfo);//得到刚刚解码的MP3帧信息
        if(MP3Info->Bitrate != mp3frameinfo.bitrate)//更新码率
        {
          MP3Info->Bitrate = mp3frameinfo.bitrate;
          AudioPlayInfo.Bitrate = mp3frameinfo.bitrate;//更新比特率
        }
				
        if(mp3frameinfo.nChans == 1)//如果是单声道
        {
          MonoChannelFill(pOutputBuffer,mp3frameinfo.outputSamps);//将数据填充为立体声
        }
				
        if(bytesleft < MAINBUF_SIZE*2)//当数组内容小于2倍MAINBUF_SIZE的时候,必须补充新的数据进来
        {
          memmove(MP3_INPUT_BUFFER,readptr,bytesleft);//将输入数组后面剩余的部分移到前面
					
          if(f_read(&fs_file, MP3_INPUT_BUFFER+bytesleft, MP3_INPUT_BUFFER_SIZE-bytesleft, (UINT*)&br))//补充余下的数据
          {
            res = AudioPlay_ReadFileError;
          }
					
          if(br < MP3_INPUT_BUFFER_SIZE-bytesleft)//如果读取的数据填不满输入数据缓冲区
          {
            memset(MP3_INPUT_BUFFER+bytesleft+br, 0, MP3_INPUT_BUFFER_SIZE-bytesleft-br);//补0
          }
					
          bytesleft = MP3_INPUT_BUFFER_SIZE;//复位读取指针和剩余字节
          readptr = MP3_INPUT_BUFFER;
        }
      }
    }
  }
	
  Play_Stop();
  f_close(&fs_file);
	
  return res;
}
