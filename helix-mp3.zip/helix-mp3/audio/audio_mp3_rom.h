#ifndef __AUDIO_MP3_ROM_H__ 
#define __AUDIO_MP3_ROM_H__

#include "audio_mp3.h"
#include "audio_common.h"

AudioPlayRes MP3_Play_ROM(uint32_t offset);

#endif
