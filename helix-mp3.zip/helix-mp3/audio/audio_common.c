//#include "common.h"
#include "audio_common.h"
#include "audio_flac.h"
#include "audio_mp3.h"
#include "audio_wav.h"
//#include "system_i2s.h"
//#include "bsp_wm8978.h"
#include "ff.h"
#include "pcm5102.h"
#include <string.h>
#include <stdio.h>
#include "system_mem.h"

AudioPlay_Info AudioPlayInfo;

/*
将单声道填充为双声道
从中间一个元素开始 将其复制到数组最后面两个
然后被复制的元素向前移动1 复制目标向前移动2
可以防止前面未被复制的数据的损坏
    (i==0)                   (i = size-1)
┌←─┬→─┐        ┌──→→→→──┬───┐
↓	   ↑    ↓        ↑                ↓      ↓
*[0]  ┘  *[1]      *[2]       [3]     [4]     [5]
            ↓        ↑        ↑
            ┕→→──┴────┘
                    (i--)
*/
void MonoChannelFill(uint16_t* buf, uint32_t size)
{
	uint16_t i;
	
	i = size-1;
	
	do
	{
		buf[2*i] = buf[i];//目标元素的第一个数
		buf[2*i + 1] = buf[i];//目标元素的第二个数
		i --;
	}
	while(i);
}
/*
void* AudioPlay_GetNextBuff(void)
{
	if(PCM5102_I2S_DMA_STREAM->CR & 1<<19)//如果现在是缓冲区1
	{
		return I2Sbuf1;
	}
	else
	{
		return I2Sbuf2;
	}
}

void* AudioPlay_GetPlayingBuff(void)
{
	if(PCM5102_I2S_DMA_STREAM->CR & 1<<19)//如果现在是缓冲区1
	{
		return I2Sbuf2;
	}
	else
	{
		return I2Sbuf1;
	}
}

void AudioPlay_BuffSwitch(void)
{
	if(PCM5102_I2S_DMA_STREAM->CR & 1<<19)//如果现在是缓冲区1
	{
		PCM5102_I2S_DMA_STREAM->CR &= ~(1<<19);
	}
	else
	{
		PCM5102_I2S_DMA_STREAM->CR |= (1<<19);
	}
}
*/
void AudioPlay_PendSem(void)
{
	//while(!DataRequestFlag)//等待传输完成
	{
		//__asm ("wfi");
		__asm volatile( "dsb" );
		__asm volatile( "wfi" );
		__asm volatile( "isb" );
	}
	//DataRequestFlag = 0;//传输完成后清除传输完成标志位
}

void AudioPlay_ClearSem(void)
{
	//DataRequestFlag = 0;
}
/*
void AudioPlay_ClearBuf(void)
{
	uint32_t i;
	for(i = 0;i < AudioPlayInfo.BufferSize;i ++)
	{
		I2Sbuf1[i] = 0;
		I2Sbuf2[i] = 0;
	}
}
*/
/** @defgroup SPI_I2S_Mode
  * @{
  */

#define I2S_Mode_SlaveTx                ((uint16_t)0x0000)
#define I2S_Mode_SlaveRx                ((uint16_t)0x0100)
#define I2S_Mode_MasterTx               ((uint16_t)0x0200)
#define I2S_Mode_MasterRx               ((uint16_t)0x0300)
#define IS_I2S_MODE(MODE) (((MODE) == I2S_Mode_SlaveTx) || \
                           ((MODE) == I2S_Mode_SlaveRx) || \
                           ((MODE) == I2S_Mode_MasterTx)|| \
                           ((MODE) == I2S_Mode_MasterRx))
uint8_t AudioPlay_I2SConfig(uint8_t Bits,uint32_t SampleRate,uint16_t BufSize)
{
  static uint8_t bits_last = 0xFF;
  uint32_t DataFormat;
  uint8_t ret = 0;

  if(bits_last != Bits)
  {
    if(Bits == 16)//16位数据
    {
      //WM8978_I2SConfig(2,0);//飞利浦标准,16位数据长度
      DataFormat = LL_I2S_DATAFORMAT_16B;
    }
    else if(Bits == 24)//24位数据
    {
      //WM8978_I2SConfig(2,2);//飞利浦标准,24位数据长度
      DataFormat = LL_I2S_DATAFORMAT_24B;
    }
    else if(Bits == 32)
    {
      //WM8978_I2SConfig(2,3);//飞利浦标准,32位数据长度
      DataFormat = LL_I2S_DATAFORMAT_32B;
    }
    else
    {
      return 1;
    }
    ret = I2S_Config(AUDIO_PLAY_I2S, I2S_Mode_MasterTx, SampleRate, DataFormat);
  }
  bits_last = Bits;
	
  I2S_TX_DMA_Init(dmaBuffer,dmaBuffer,BufSize,Bits);//配置DMA
	
  if(ret)
  {
    return 2;
  }
	
  return 0;
}

AudioFileType Audio_CheckFileExtname(char* path)
{
	char* temp;
	
	temp = strrchr(path,'.');
	
	temp ++;
	
	if(!strcasecmp(temp,"MP3"))
		return AudioFileType_MP3;
	else if(!strcasecmp(temp,"FLAC") || !strcasecmp(temp,"FLA"))
		return AudioFileType_FLAC;
	else if(!strcasecmp(temp,"WAV"))
		return AudioFileType_WAV;
	
	return AudioFileType_ERROR;
}

void AudioPlayFile(char* path,char* fname)
{
	char music_path[64];
	
	sprintf(music_path,"1:%s/%s",path,fname);
	memset(&AudioPlayInfo,0,sizeof(AudioPlay_Info));
	
	switch(Audio_CheckFileExtname(fname))
	{
		case AudioFileType_MP3:
			AudioPlayInfo.PlayRes = MP3_Play(music_path);
			break;
		case AudioFileType_WAV:
			AudioPlayInfo.PlayRes = WAV_Play(music_path);
			break;
		case AudioFileType_FLAC:
			AudioPlayInfo.PlayRes = FLAC_Play(music_path);
			break;
		default:
			break;
	}
}

void Play_Start(void)
{
  //WM8978_I2S_DMA_CMD(ENABLE);//启动传输
  //Start_DAC_DMA (SPI2, DMA1, 4, AudioPlayInfo.Bitrate, uint32_t DataFormat, uint32_t *outbuf, uint32_t bufsize);
  PCM5102_I2S_DMA_STREAM->CR |= (uint32_t)DMA_SxCR_EN;
}

void Play_Stop(void)
{
  //WM8978_I2S_DMA_CMD(DISABLE);//关闭传输
  PCM5102_I2S_DMA_STREAM->CR &= ~(uint32_t)DMA_SxCR_EN;
  //AudioPlay_BuffSwitch();//切换缓冲区 防止恢复播放的时候出现破音
}
//#define DMA_IT_TC                                DMA_SxCR_TCIE
//#define DMA_IT_HT                                DMA_SxCR_HTIE
//#define DMA_IT_TE                                DMA_SxCR_TEIE
//#define DMA_IT_DME                               DMA_SxCR_DMEIE
//#define DMA_IT_FE                                0x00000080U
static void I2S_DMAStop(void)
{
  /* Disable the I2S DMA tx Stream/Channel */

  /* Disable all the transfer interrupts */
  PCM5102_I2S_DMA_STREAM->CR  &= ~(DMA_SxCR_TCIE | DMA_IT_HT | DMA_SxCR_TEIE | DMA_SxCR_DMEIE);
  PCM5102_I2S_DMA_STREAM->FCR &= ~(0x00000080U);

  /* Disable the stream */
  PCM5102_I2S_DMA_STREAM->CR &=  ~DMA_SxCR_EN;

  /* Clear all interrupt flags at correct offset within the register */
  DMA1->HIFCR = 0x3FU;

  /* Disable I2S peripheral */
  PCM5102_I2S->I2SCFGR &= ~(SPI_I2SCFGR_I2SE);

  /* Clear UDR flag */
  PCM5102_I2S->SR &= ~(SPI_SR_UDR);

  /* Disable the I2S Tx DMA requests */
  PCM5102_I2S->CR2 &= ~(SPI_CR2_TXDMAEN);

  /* Clear OVR flag */
  PCM5102_I2S->DR = 0;
  PCM5102_I2S->SR &= ~(SPI_SR_OVR);
}
static void I2S_DeInit(void)
{
  /* Disable the I2S Peripheral Clock */
  PCM5102_I2S->I2SCFGR &= ~(SPI_I2SCFGR_I2SE);
  RCC->APB1ENR &= ~(RCC_APB1ENR_SPI2EN);

}


int FillReadBuffer(unsigned char *readBuf, unsigned char *readPtr, int bufSize, int bytesLeft, FILE *infile)
{
  UINT nRead;
  uint32_t bytes_to_read = bufSize - bytesLeft;//How much more data can be added to the buffer?

  memcpy(readBuf, readPtr, bytesLeft);	//Copy the rest of the buffer to the front
  f_read(infile, readBuf + bytesLeft, bytes_to_read, &nRead);
  if(nRead < bytes_to_read)
    memset(readBuf + bytesLeft + nRead, NULL, bytes_to_read - nRead);

  //return (uint32_t) bytesLeft + (uint32_t) nRead;
  return (uint32_t) nRead;
}

void wait4_I2S_DMA_SyncSignal(void)		//TODO: static???
{
  while (DMABufferState == DMABuffer_Full)
  {
    vTaskDelay(2);
  }
}
void I2S_TxHalfCpltCallback(uint32_t value)
{
  UNUSED(value);
  DMABufferState |= DMABuffer_1stHalf_empty;
}

void I2S_TxCpltCallback(uint32_t value)
{
  UNUSED(value);
  DMABufferState |= DMABuffer_2ndHalf_empty;
}

void fill_DMAbuffer(uint16_t* destinationBuffer, uint16_t* sourceBuffer, uint32_t destinationBufferSize)
{
// !!! The code snippet for debugging the buffer and its size, will be removed in the final version of the programme !!!!/
//  uint32_t inbufsize  = sizeof(unsigned char)*READ_BUFFER_SIZE;          //File input buffer = 4096
//
//  uint32_t decbufsize = sizeof(uint16_t)	*DECODED_AUDIO_FRAME_SIZE;     //Data decoding buffer = 2304
//  uint32_t decbufWav  = sizeof(uint16_t)	*DECODED_AUDIO_FRAME_SIZE_WAV; //Data decoding buffer - WAV = 2000
//  uint32_t toCopy     = destinationBufferSize;                           //Amount of data to copy = 2000 dla WAV
//
//
//  uint32_t dmabufsize = sizeof(dmaBuffer);                     //bufor I2S = 9216
//  uint32_t dmabufWAv  = sizeof(uint16_t)*DMA_BUFFER_SIZE_WAV;  //bufor i2s potrzebny dla WAV = 4000 dla WAV


  switch (DMABufferState)
  {
	//case (DMABuffer_Full):	//This situation is impossible because it would cause popping sounds during playback
	case (DMABuffer_1stHalf_empty):
      memcpy(destinationBuffer, sourceBuffer, destinationBufferSize);		//kopiuje rozkodowane dane do 1st po艂owy bufora DMA
	  DMABufferState &= 0b11111110;
	  break;
	case (DMABuffer_2ndHalf_empty):
	  memcpy(destinationBuffer+destinationBufferSize/2, sourceBuffer, destinationBufferSize);		//kopiuje rozkodowane dane do 2nd po艂owy bufora DMA
	  DMABufferState &= 0b11111101;
	  break;
	case (DMABuffer_1stHalf_empty | DMABuffer_2ndHalf_empty):
      Play_Stop();
	  printf("PLAYER: Both halfs of DMA buffer empty. Buffer synchronisation issue.\r\n");
	  printf("PLAYER: DMA transmission stopped.\r\n");
	  memcpy(destinationBuffer, sourceBuffer, destinationBufferSize);		//kopiuje rozkodowane dane do 1st po艂owy bufora DMA
	  DMABufferState &= 0b11111110;
	  break;
	default:
      break;
  }
}
