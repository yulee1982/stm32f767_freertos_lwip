#ifndef __AUDIO_MP3_H__ 
#define __AUDIO_MP3_H__

#include "ff.h"
#include "audio_common.h"

#define MP3_INPUT_BUFFER_SIZE 4096//MP3解码时,文件buf大小

typedef struct//ID3V1 标签
{
	unsigned char id[3];			//ID,TAG三个字母
	unsigned char title[30];	//歌曲名字
	unsigned char artist[30];	//艺术家名字
	unsigned char album[30];	//专辑名名字
	unsigned char year[4];		//年代
	unsigned char comment[30];	//备注
	unsigned char genre;			//流派
} __attribute__ ((packed)) ID3V1_Tag;

typedef struct//ID3V2 标签头
{
    unsigned char id[3];		//ID
    unsigned char mversion;	//主版本号
    unsigned char sversion;	//子版本号
    unsigned char flags;		//标签头标志
    unsigned char size[4];		//标签信息大小(不包含标签头10字节) 标签大小=size+10.
} __attribute__ ((packed)) ID3V2_TagHead;

//ID3V2.3 版本帧头
typedef struct
{
	unsigned char id[4];			//帧ID
	unsigned char size[4];		//帧大小
	unsigned char flags[2];		//帧标志
} __attribute__ ((packed)) ID3V23_TagFrameHead;

typedef struct//MP3 Xing帧信息(没有全部列出来,仅列出有用的部分)
{
	unsigned char id[4];			//帧ID,为Xing/Info
	unsigned char flags[4];		//存放标志
	unsigned char frames[4];	//总帧数
	unsigned char fsize[4];		//文件总大小(不包含ID3)
} __attribute__ ((packed)) MP3_FrameXing;
 
typedef struct//MP3 VBRI Frame information (not fully listed, only the useful parts are shown)
{
    unsigned char id[4];		//Frame ID, for Xing/Info
	unsigned char version[2];	//Version number
	unsigned char delay[2];		//Delay
	unsigned char quality[2];	//音频质量,0~100,越大质量越好
	unsigned char fsize[4];		//文件总大小
	unsigned char frames[4];	//文件总帧数
} __attribute__ ((packed)) MP3_FrameVBRI;

typedef struct//MP3 control
{
	unsigned char Channels;			  //Number of audio channels
	unsigned int TotalSec;			  //Song top playtime, unit: seconds
	unsigned int CurrentSec;		  //Current playtime
	unsigned int Bitrate;	   		  //Bitrate
	unsigned int Samplerate;		  //Sampling rate
	unsigned short SampleSize;		  //PCM output data size (in 16-bit units),Mono actual output *2 (for DAC output)
	unsigned int DataStartOffset;	  //The starting position of the data frame (offset in the file)
	unsigned int DataSize;			  //The data size of MP3 after removing all kinds of information
	unsigned int bytes_left;
} __attribute__ ((packed)) MP3_Info;

AudioPlayRes MP3_Play(char* path);

#endif

