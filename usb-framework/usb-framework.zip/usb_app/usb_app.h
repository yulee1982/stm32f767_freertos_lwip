#ifndef USB_APP_H_
#define USB_APP_H_


void prvUSBappTask(void * pvParameters);  //任务函数

#endif /* USB_APP_H_ */
